#include<stdio.h>

int exibeDivisores(int div){
	
	int i;
	
	div=0; 
	
	for(i=1; i<=20; i++){
		if(i%2==0){
			div=i;
			return div;
		}
	}
}

main(){
	
	int i, div, v;
	
	for(i=1; i<=20; i++){
		v= exibeDivisores(i);
		printf("%d\n", i);
		printf("d\n", v);
	}
}

