#include <stdio.h>

void exibeDivisores(int num) {
    
	int i;
	printf("%d:", num);
    for (i = 1; i <= num; i++) {
        if (num % i == 0) {
            printf(" %d", i);
        }
    }
    printf("\n");
}

int main() {
	
	int i;
    for (i = 1; i <= 20; i++) {
        exibeDivisores(i);
    }
    return 0;
}

