#include <stdio.h>

int maiorNumero(int a, int b) {
    if (a > b) {
        return a;
    } else if (b > a) {
        return b;
    } else {
        return -1;
    }
}

int main() {
    int N,i;
    printf("Digite a quantidade de duplas: ");
    scanf("%d", &N);

    for ( i = 0; i < N; i++) {
        int num1, num2;
        printf("Digite dois n�meros positivos (dupla %d): ", i + 1);
        scanf("%d %d", &num1, &num2);

        int resultado = maiorNumero(num1, num2);

        if (resultado == -1) {
            printf("Eles s�o iguais\n");
        } else {
            printf("O maior n�mero �: %d\n", resultado);
        }
    }

    return 0;
}

