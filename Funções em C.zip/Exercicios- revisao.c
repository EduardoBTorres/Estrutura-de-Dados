#include <stdio.h>

main(){
	
	int alunos, codigo, i,c;
	float altura[alunos], maior, media;
	
	maior=0;
	c=0;
	
	printf("Ler Q: ");
	scanf("%d", &alunos);
	
	for(i=0; i<alunos; i++){
		printf("Altura: ");
		scanf("%f", &altura[i]);
		
		printf("Codigo: ");
		scanf("%d", &codigo);	
		
		if(altura[i]>maior){
			maior= altura[i];
		}
		
		if(codigo==2){
			c++;
			media= altura[i]/c;
		}		
}
	
	printf("Maior altura: %f", maior);
	printf("Media das alunas: %f", media);
}
