#include<stdio.h>

main(){
	
	int linhas, colunas, L, C, matriz[L][C], valores, i, j;
	
	do{
	
		printf("Quantidade de linhas: ");
		scanf("%d", &linhas);
		
	}while(linhas<0 || linhas>10);
	
	do{
	
		printf("Quantidade de colunas: ");
		scanf("%d", &colunas);
		
	}while(colunas<0 || colunas>10);
	
	for(i=0; i<linhas; i++){
		for(j=0; j<colunas; j++){
			printf("Matriz LC: ");
			scanf("%d", &matriz[i][j]);
		}
	}
	
	do{
		printf("Valor: ");
		scanf("%d", &valores);
		
		for(i=0; i<linhas; i++){
			for(j=0; j<colunas; j++){
				
				if(valores == matriz[i][j]){
					printf("Esta na matriz");
		}
			else{
			printf("Nao esta na matriz");
	}
}
}
	}while(valores>0);	
}
