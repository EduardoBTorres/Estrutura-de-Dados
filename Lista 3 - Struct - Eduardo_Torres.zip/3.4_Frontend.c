#include "Cheque.h"
#include <stdio.h>

int main(){
	
	Cheque cheque1, cheque2, valor1, valor2;
	float v, w, x;
	int z, y, u, s;
	
	printf("Digite numero do cheque 1: ");
	scanf("%d", &cheque1.numero);
	
	criaCheque(&cheque1, cheque1.numero);
	
	printf("Digite numero do cheque 2: ");
	scanf("%d", &cheque2.numero);
	
	criaCheque(&cheque2, cheque2.numero);
	
	printf("Digite valor do cheque 1: ");
	scanf("%f", &valor1.valor);
	
	emiteCheque(&cheque1, cheque1.valor);
	
	printf("Digite valor do cheque 2: ");
	scanf("%f", &valor2.valor);
	
	emiteCheque(&cheque2, cheque2.valor);
	
	exibeCheque(cheque1.numero, cheque1.situacao, cheque1.valor);
	
	exibeCheque(cheque2.numero, cheque2.situacao, cheque2.valor);
	
	v= obtemValor(cheque1);
	printf("Valor cheque 1: %f", v);
	
	w= obtemValor(cheque2);
	printf("Valor cheque 2: %f", w);
	
	if(obtemValor(cheque1) > obtemValor(cheque2)){
		x= compensaCheque(&cheque1);
	} else{
		x= compensaCheque(&cheque2);
	}
	
	z= obtemSituacao(cheque1.situacao);
	printf("Situacao cheque 1: %d", z);
	
	y= obtemSituacao(cheque2.situacao);
	printf("Situacao cheque 2: %d", y);
	
	u= obtemNumero(cheque1);
	printf("Numero do cheque 1: %d", u);
	
	s= obtemNumero(cheque2);
	printf("Numero do cheque 2: %d", s);
	
	return 0;			
}
